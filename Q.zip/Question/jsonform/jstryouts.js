
function openwin(){
    win1=window.open("modal.html","","width=200,height=300,top=300,left=200");
}
function closewin(){
    win1.close();
}