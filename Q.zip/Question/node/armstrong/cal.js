function Armstrong(number)
	{
		var flag,number,remainder,addition = 0;
		

		flag = number;
		while(number > 0)
		{
			remainder = number%10;
			addition = addition + remainder*remainder*remainder;
			number = parseInt(number/10);
		}

		if(addition == flag)
		{
			return "-The inputed number is Armstrong";
		}
		else
		{
			return "-The inputed number is not Armstrong";
		}
	}


module.exports={Armstrong};
