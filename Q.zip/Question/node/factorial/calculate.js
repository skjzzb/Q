function add(n1,n2){
    return parseInt(n1)+parseInt(n2);
}
sub=function(n1,n2){
    return n1-n2;

}
function factorial(x) 
{ 

  if (x === 0)
 {
    return 1;
 }
  return x * factorial(x-1);
         
}



module.exports={add,sub,factorial};
