var cal=require('./calculate');
//console.log(cal.add(3,4));

var p=require('prompt');
console.log('Enter values');
p.start();
/*p.get(['a','b'],function(err,data){
    if(err) throw err;
    // console.log(data.a);
    // console.log(data.b);
    console.log(cal.add(data.a,data.b));
})
*/
p.get(['a'],function(err,data){
    if(err) throw err;
    // console.log(data.a);
    // console.log(data.b);
    console.log(cal.factorial(data.a));
})