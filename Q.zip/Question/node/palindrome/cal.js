function Palindrome(number)
	{
		var rem, temp, final = 0;
		

		temp = number;
		while(number>0)
		{
			rem = number%10;
			number = parseInt(number/10);
			final = final*10+rem;
		}
		if(final==temp)
		{
			return "The inputed number is Palindrome";
		}
		else
		{
			return "The inputted number is not palindrome";
		}
	}


module.exports={Palindrome};
